#pragma once
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <DX/d3d9.h>
#include <ImGui/imgui.h>
#include <ImGui/imgui_impl_dx9.h>
#include <ImGui/imgui_impl_win32.h>
#include <tchar.h>